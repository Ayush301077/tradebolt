import React from 'react'

const SearchCoin = () => {
  return (
    <div>
      SearchCoin
    </div>
  )
}

export default SearchCoin
