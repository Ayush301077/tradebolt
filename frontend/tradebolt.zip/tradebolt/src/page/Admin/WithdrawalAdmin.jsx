import React from 'react'

const WithdrawalAdmin = () => {
  return (
    <div>
      WithdrawalAdmin
    </div>
  )
}

export default WithdrawalAdmin
